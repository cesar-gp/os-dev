#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>
#include "include/stdio.h"

static uint16_t* screen = (uint16_t*) 0xB8000;

static uint8_t vga_x = 0;
static uint8_t vga_y = 0;
static uint8_t vga_color = 0x0F;

void _vga_write(uint8_t c, uint16_t color, uint8_t x, uint8_t y) {
    uint16_t pos = x + y * VGA_WIDTH;
    screen[pos] = c | ((uint16_t) color << 8);
}

void _vga_move(uint8_t x, uint8_t y) {
    // Salto de linea
    if(x == VGA_WIDTH) x = 0, y++;

    // Scroll de página
    if(y == VGA_HEIGHT) {
        for(y = 0; y < VGA_HEIGHT; y++)
            for(x = 0; x < VGA_WIDTH; x++) {
            	// Copiar cada linea, excepto la primera, hacia la anterior.
                if(y) _vga_write(screen[x+VGA_WIDTH*y], screen[x+VGA_WIDTH*y] >> 8, x, y - 1);

                // Sustituir su contenido por espacios con fondo negro
                _vga_write(' ', 0x07, x, y);
            }

        // Mover el cursor hacia el primer caracter de la última linea
        x = 0, y = VGA_HEIGHT - 1;
    }

    // Guardar los cambios
    vga_x = x, vga_y = y;
}

uint8_t _putc(uint8_t c) {
    switch(c) {
        case '\n':
            _vga_move(vga_x, vga_y + 1);
            return 1;
        case '\r':
            _vga_move(0, vga_y);
            return 1;
        case '\t':
            uint16_t dst = vga_x + (4 - vga_x % 4);
            for(; vga_x < dst && vga_x < VGA_WIDTH; vga_x++)
            	_vga_write(' ', vga_color, vga_x, vga_y);

            if(vga_x == VGA_WIDTH) vga_x = 0, vga_y++;
            return 1;
    }

    _vga_write(c, vga_color, vga_x, vga_y);
    _vga_move(vga_x + 1, vga_y);

    return 1;
}

uint32_t _puts(const uint8_t* s) {
    uint32_t written = 0;
    for(; s[written]; written++) _putc(s[written]);
    return written;
}

uint8_t _num_to_str(uint8_t* str, uint64_t num) {
    const uint8_t digits[] = "0123456789";
    
    // Si el número es 0, devolver una string con el caracter '0'.
    if(num == 0) {
        str[0] = '0';
        str[1] = '\0';

        return 1;
    }

    // Dividir entre 10 hasta que el número sea 0.
    // Ir guardando los caracteres ASCII en 'reverse' y la longitud en 'numlen'
    uint16_t numlen = 0;
    uint8_t reverse[20]; // 20: máximo de cifras de un número de 64 bits.
    while(num) {
        reverse[numlen] = digits[num % 10];
        numlen++;

        num /= 10;
    }

    // Invertir los caracteres de 'reverse' y guardarlos en 'str'
    for(uint8_t i = 1; i <= numlen; i++)
        str[i - 1] = reverse[numlen - i];

    // Apuntar un caracter nulo al final de 'str' para indicar el fin de string.
    str[numlen] = '\0';

    // Nota: si no se sabe la longitud que puede tener el núm. final,
    // lo mejor es dejar 21 bytes de espacio en el buffer.

    return numlen;
}

uint16_t _putn(uint64_t num, bool negative) {
    uint8_t written = 0;

    uint8_t str[20];
    _num_to_str(str, num);

    if(negative) written += _putc('-');
    written += _puts(str);
    return written;
}

uint32_t _vprintf(const uint8_t* fmt, va_list args) {
    uint32_t written = 0;

    uint8_t state = PRINTF_STATE_DEF;
    uint8_t length = PRINTF_LENGTH_DF;

    while(*fmt) {
    	// Este iterador examina cada letra de la string 'fmt' hasta su final.

        switch(state) {
            // Este switch cambia el comportamiento según el estado
            // (DEFAULT, LENGTH o SPECIFIER).

            case PRINTF_STATE_DEF:
                // Estado DEFAULT: imprime caracteres y detecta '%'
                switch(*fmt) {
                    case '%':
                        // Si hay un '%' pasa al estado LENGTH
                        state = PRINTF_STATE_LEN;
                        fmt++;
                        break;
                    default:
                        written += _putc(*fmt);
                        fmt++;
                        break;
                }
                break;
            case PRINTF_STATE_LEN:
                // Estado LENGTH: detecta 'l', 'h', 'll' y 'hh'.
                // Si termina o encuentra cualquier otra letra,
                // salta al estado SPECIFIER.
                switch(*fmt) {
                    case 'l':
                        // Si hay una 'l', aumenta longitud.
                        if(length == PRINTF_LENGTH_L) {
                            length = PRINTF_LENGTH_LL;
                            state = PRINTF_STATE_SPC;
                            fmt++;
                        } else {
                            length = PRINTF_LENGTH_L;
                            fmt++;
                        }
                        break;
                    case 'h':
                        // Si hay una 'h', la disminuye.
                        if(length == PRINTF_LENGTH_H) {
                            length = PRINTF_LENGTH_HH;
                            state = PRINTF_STATE_SPC;
                            fmt++;
                        } else {
                            length = PRINTF_LENGTH_H;
                            fmt++;
                        }
                        break;
                    default:
                        // Ante otro caracter, pasa al estado SPECIFIER.
                        state = PRINTF_STATE_SPC;
                        break;
                }
                break;
            case PRINTF_STATE_SPC:
                // Estado SPECIFIER: detecta formateadores e imprime los argumentos.
                switch(*fmt) {
                    case 'd':
                    case 'i':
                        // %d, %i: imprimir núm. con signo.
                        if(length == PRINTF_LENGTH_LL) {
                            int64_t num = va_arg(args, int64_t);

                            // Si es negativo, lo detecta y lo apunta
                            // pero pasa un positivo a la función _putn().
                            bool negative = num < 0;
                            if(negative) num *= -1;
                            written += _putn(num, negative);
                        } else {
                            int32_t num = va_arg(args, int32_t);

                            bool negative = num < 0;
                            if(negative) num *= -1;
                            written += _putn(num, negative);
                        }
                        break;
                    case 'u':
                        // %u: imprimir núm. sin signo.
                        if(length == PRINTF_LENGTH_LL)
                            written += _putn(va_arg(args, uint64_t), false);
                        else
                            written += _putn(va_arg(args, uint32_t), false);
                        break;
                    case 'c':
                        // %c: imprimir caracter con _putc().
                        written += _putc(va_arg(args, uint32_t));
                        break;
                    case 's':
                        // %s: imprimir string con _puts().
                        written += _puts(va_arg(args, const uint8_t*));
                        break;
                    case '%':
                        // %%: imprimir '%'.
                        written += _putc('%');
                        break;
                }

                // Volver al estado DEFAULT.
                state = PRINTF_STATE_DEF;
                length = PRINTF_LENGTH_DF;
                fmt++;
                break;
        }
    }

    return written;
}

uint32_t printf(const uint8_t* fmt, ...) {
    va_list args;                           // Declaramos una lista (va_list) de argumentos.
    va_start(args, fmt);                    // Inicializamos la lista desde 'fmt' para alante.
    uint32_t written = _vprintf(fmt, args); // Procesar los argumentos
    va_end(args);                           // Cerrar la lista de argumentos.

    return written;
}

void vga_clear() {
    // Rellenar la pantalla de espacios.
    for(uint8_t y = 0; y < VGA_HEIGHT; y++)
        for(uint8_t x = 0; x < VGA_WIDTH; x++)
            _vga_write(' ', vga_color, x, y);

    // Mover el cursor al punto de inicio.
    _vga_move(0, 0);
}