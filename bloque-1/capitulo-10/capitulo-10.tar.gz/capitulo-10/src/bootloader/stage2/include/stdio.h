#pragma once

#include <stdint.h>

#define VGA_WIDTH 80
#define VGA_HEIGHT 25

#define PRINTF_STATE_DEF 0
#define	PRINTF_STATE_LEN 1
#define PRINTF_STATE_SPC 2

#define PRINTF_LENGTH_HH 0
#define PRINTF_LENGTH_H 1
#define PRINTF_LENGTH_DF 2
#define PRINTF_LENGTH_L 3
#define PRINTF_LENGTH_LL 4

void vga_clear();
uint32_t printf(const uint8_t* fmt, ...);

uint8_t _num_to_str(uint8_t* str, uint64_t num);