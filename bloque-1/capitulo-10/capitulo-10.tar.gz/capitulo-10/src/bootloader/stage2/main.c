#include "include/stdio.h"

void quit() {
    for(;;);
}

void cstart() {
    vga_clear();

    printf("Bienvenido al bootloader!\n\r");
    printf("\n");
    printf("Prueba de formatos:\n\r");
    printf("\n");
    printf("Caracter ASCII: %c.\n\r", '$');
    printf("Numeros con signo: %lld, %lld, %ld, %d, %hd, %hhd.\n\r", (int64_t) -1234, (int64_t) 5678, (int32_t) -90, (int32_t) 123, (int16_t) -4567, (int8_t) 89);
    printf("Numeros sin signo: %llu, %lu, %u, %hu, %hhu.\n\r", (uint64_t) 123456, (uint32_t) 7890, (uint32_t) 1234, (uint16_t) 567, (uint8_t) 89);
    printf("Cadena de texto: \"%s\".\n\r", "Holaa!");
    printf("Escape: %%.\n\r");

    quit();
}