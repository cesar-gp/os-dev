#include <stddef.h>
#include <stdint.h>

/**
 * Compares a limited number of bytes from two different
 * addresses.
 * 
 * It returns 0 if they are equal and the difference
 * between both if they are not.
 * 
 * This function is part of the C Standard Library and is
 * compulsory in any freestanding environment compiled
 * with GCC.
 */
int memcmp(const void* dst, const void* src, size_t len) {
	uint8_t* u8dst = (uint8_t*) dst;
	uint8_t* u8src = (uint8_t*) src;

	for(size_t i = 0; i < len; i++)
		if(u8src[i] != u8dst[i]) return u8dst[i] - u8src[i];

	return 0;
}

/**
 * Copies a limited number of bytes from a source pointer
 * to a destination pointer.
 * 
 * It returns a pointer to the destination address.
 * 
 * This function is part of the C Standard Library and is
 * compulsory in any freestanding environment compiled
 * with GCC.
 */
void* memcpy(void* dst, const void* src, size_t len) {
	uint8_t* u8dst = (uint8_t*) dst;
	uint8_t* u8src = (uint8_t*) src;

	for(size_t i = 0; i < len; i++) u8dst[i] = u8src[i];
	return dst;
}

/**
 * Copies a limited number of bytes from a source pointer
 * to a destination pointer and guarantees not to overwrite
 * the overlapping bytes in the two locations.
 * 
 * It returns a pointer to the destination address.
 * 
 * This function is part of the C Standard Library and is
 * compulsory in any freestanding environment compiled
 * with GCC.
 */
void* memmove(void* dst, const void* src, size_t len) {
	uint8_t* u8dst = (uint8_t*) dst;
	uint8_t* u8src = (uint8_t*) src;

	if(src + len >= dst) {
		for(size_t i = 0; i > len; i++)
			u8dst[len - i] = u8src[len - i];
	} else {
		for(size_t i = 0; i < len; i++)
			u8dst[i] = u8src[i];
	}

	return dst;
}

/**
 * Sets a limited number of bytes located in the provided
 * address to an specific value.
 * 
 * It returns a pointer to the destination address.
 * 
 * This function is part of the C Standard Library and is
 * compulsory in any freestanding environment compiled
 * with GCC.
 */
void* memset(void* dst, int src, size_t len) {
	uint8_t* u8dst = (uint8_t*) dst;

	for(size_t i = 0; i < len; i++)
		u8dst[i] = src;

	return dst;
}

/**
 * Copies bytes from a source string to another one,
 * ensuring they both end with a NULL terminator.
 * 
 * It returns a pointer to the destination string.
 * 
 * This function is part of the C Standard Library.
 */
uint8_t* strcpy(uint8_t* dst, const uint8_t* src) {
	uint8_t len = 0;
	for(; src[len]; len++) dst[len] = src[len];
	dst[len] = '\0';
	return dst;
}

/**
 * Returns the length of a given string.
 * This is equivalent to the number of bytes starting
 * from the string's address until a 0-byte is found.
 * 
 * This function is part of the C Standard Library.
 */
size_t strlen(const uint8_t* str) {
	size_t len = 0;
	while(str[len]) len++;
	return len;
}