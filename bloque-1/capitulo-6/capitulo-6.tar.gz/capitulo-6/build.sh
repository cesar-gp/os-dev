# Definir variables
GCC="/run/media/cesitah/Crucial_X6/Aplicaciones/i686-elf-gcc/bin/i686-elf-gcc"

# Asegurarse de borrar builds desactualizadas
rm -rf build

# Crear la carpeta 'build' y todas las subcarpetas necesarias
mkdir -p build/bin
mkdir -p build/obj

# Compilar stage1.bin
nasm -f bin -o build/bin/stage1.bin src/stage1/stage1.asm

# Compilar y enlazar stage2.bin
nasm -f elf -o build/obj/entry.obj src/stage2/entry.asm
${GCC} -T src/stage2/linker.ld -nostdlib -o build/bin/stage2.bin build/obj/entry.obj -lgcc

# Formatear el disco
dd if="/dev/zero" of="build/disco.img" bs=512 count=2880
mkfs.fat -F 12 -n "SCRATCH  OS" build/disco.img

# Instalar stage1
dd if="build/bin/stage1.bin" of="build/disco.img" conv=notrunc

# Instalar stage2
mcopy -i build/disco.img build/bin/stage2.bin "::stage2.bin"

# Emular el bootloader con QEMU
qemu-system-i386 -fda build/disco.img