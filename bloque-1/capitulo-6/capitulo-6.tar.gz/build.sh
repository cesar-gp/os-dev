# SETUP
GCC="localización del ejecutable i686-elf-gcc de tu cross-compiler"

rm -rf build
mkdir build

# STAGE1
nasm -f bin -o build/stage1.bin stage1/stage1.asm

# STAGE2
nasm -f elf -o build/entry.obj stage2/entry.asm
${GCC} -T stage2/linker.ld -nostdlib -o build/stage2.bin build/entry.obj -lgcc

# DISCO
dd if="/dev/zero" of="build/disco.img" bs=512 count=2880
mkfs.fat -F 12 -n "SCRATCH  OS" build/disco.img
dd if="build/stage1.bin" of="build/disco.img" conv=notrunc

mcopy -i build/disco.img build/stage2.bin "::stage2.bin"

# QEMU
qemu-system-i386 -fda build/disco.img