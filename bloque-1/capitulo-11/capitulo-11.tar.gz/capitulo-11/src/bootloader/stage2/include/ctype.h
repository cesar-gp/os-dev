#pragma once

#include <stdint.h>
#include <stdbool.h>

bool isalpha(uint8_t c);
bool isdigit(uint8_t c);
bool isprint(uint8_t c);
bool islower(uint8_t c);
bool isupper(uint8_t c);
uint8_t tolower(uint8_t c);
uint8_t toupper(uint8_t c);