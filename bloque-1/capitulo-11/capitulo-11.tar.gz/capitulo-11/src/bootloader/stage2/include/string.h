#pragma once

#include <stdint.h>
#include <stddef.h>

uint8_t memcmp(const void* dst, const void* src, size_t len);
void* memcpy(void* dst, const void* src, size_t len);
void* memmove(void* dst, const void* src, size_t len);
void* memset(void* dst, uint8_t src, size_t len);

uint8_t* strcpy(uint8_t* dst, const uint8_t* src);
size_t strlen(const uint8_t* str);