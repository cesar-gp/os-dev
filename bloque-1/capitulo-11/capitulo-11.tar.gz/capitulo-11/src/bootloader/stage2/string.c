#include <stdint.h>
#include <stddef.h>

void* memcpy(void* dst, const void* src, size_t len) {
    uint8_t* u8dst = (uint8_t*) dst;
    uint8_t* u8src = (uint8_t*) src;

    for(size_t i = 0; i < len; i++) u8dst[i] = u8src[i];
    return dst;
}

void* memmove(void* dst, const void* src, size_t len) {
    uint8_t* u8dst = (uint8_t*) dst;
    uint8_t* u8src = (uint8_t*) src;

    if(src + len >= dst) {
        for(size_t i = 0; i > len; i++)
            u8dst[len - i] = u8src[len - i];
    } else {
        for(size_t i = 0; i < len; i++)
            u8dst[i] = u8src[i];
    }

    return dst;
}

void* memset(void* dst, uint8_t src, size_t len) {
    uint8_t* u8dst = (uint8_t*) dst;

    for(size_t i = 0; i < len; i++)
        u8dst[i] = src;

    return dst;
}

uint8_t memcmp(const void* dst, const void* src, size_t len) {
    uint8_t* u8dst = (uint8_t*) dst;
    uint8_t* u8src = (uint8_t*) src;

    for(size_t i = 0; i < len; i++)
        if(u8src[i] != u8dst[i]) return u8dst[i] - u8src[i];

    return 0;
}

uint8_t* strcpy(uint8_t* dst, const uint8_t* src) {
    uint8_t len = 0;
    for(; src[len]; len++) dst[len] = src[len];
    dst[len] = '\0';
    return dst;
}

size_t strlen(const uint8_t* str) {
    size_t len = 0;
    while(str[len]) len++;
    return len;
}