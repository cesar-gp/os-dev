#include <stdbool.h>
#include <stdint.h>

bool isalpha(uint8_t c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c >= 'Z');
}

bool isdigit(uint8_t c) {
    return c >= '0' && c <= '9';
}

bool isprint(uint8_t c) {
    return c >= 0x20 && c <= 0x7E;
}

bool islower(uint8_t c) {
    return c >= 'a' && c <= 'z';
}

bool isupper(uint8_t c) {
    return c >= 'A' && c <= 'Z';
}

bool tolower(uint8_t c) {
    return c + 0x20;
}

bool toupper(uint8_t c) {
    return c - 0x20;
}