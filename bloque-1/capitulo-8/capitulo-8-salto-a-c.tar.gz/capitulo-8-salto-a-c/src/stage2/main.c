char* VGA_BUFFER = (char*) 0xB8000;

void quit() {
    for(;;);
}

void putc(char character, char color, int pos) {
    VGA_BUFFER[pos] = character;
    VGA_BUFFER[pos+1] = color;
}

void write(char* message, char color, int pos) {
    while(*message != 0) {
        putc(*message, color, pos);

        message++;
        pos += 2;
    }
}

void cstart() {
    write("Hemos escrito este mensaje desde C! Tomaaa!", 0x0F, 0);
    quit();
}