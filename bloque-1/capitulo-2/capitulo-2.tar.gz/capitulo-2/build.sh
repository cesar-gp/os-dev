# Asegurarse de borrar builds desactualizadas
rm -rf build

# Crear la carpeta 'build'
mkdir build

# Crear nuestro disco 'build/boot.img'
nasm -f bin -o build/boot.obj src/boot.asm
dd if=/dev/zero of=build/boot.img bs=512 count=2880
dd if=build/boot.obj of=build/boot.img conv=notrunc

# Emularlo con QEMU
qemu-system-i386 -fda build/boot.img